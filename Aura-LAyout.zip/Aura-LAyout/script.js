document.addEventListener('DOMContentLoaded', function() {
  // Initialize mobile sidenav
  const sidenavs = document.querySelectorAll('.sidenav');
  M.Sidenav.init(sidenavs);

  // Initialize modals
  const modals = document.querySelectorAll('.modal');
  M.Modal.init(modals);

  // Initialize form selects
  const selects = document.querySelectorAll('select');
  M.FormSelect.init(selects);

  // Load apartments
  loadApartments();
});

function showAddListing() {
  // Hide home sections
  document.querySelector('.hero').style.display = 'none';
  document.querySelector('.search-container').style.display = 'none';
  document.querySelector('#apartments-container').parentElement.style.display = 'none';

  // Show add listing form
  document.getElementById('add-listing-page').style.display = 'block';
  window.scrollTo(0, 0);
}

function showHomePage() {
  // Show home sections
  document.querySelector('.hero').style.display = 'flex';
  document.querySelector('.search-container').style.display = 'block';
  document.querySelector('#apartments-container').parentElement.style.display = 'block';

  // Hide add listing form
  document.getElementById('add-listing-page').style.display = 'none';
}